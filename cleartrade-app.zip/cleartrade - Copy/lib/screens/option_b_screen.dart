import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/ai_service.dart';

class OptionBScreen extends StatefulWidget {
  final Map<String, String> data;
  const OptionBScreen({super.key, required this.data});
  @override
  State<OptionBScreen> createState() => _OptionBScreenState();
}

class _OptionBScreenState extends State<OptionBScreen> {
  Map<String, dynamic>? _docs;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadDocs();
  }

  Future<void> _loadDocs() async {
    setState(() { _loading = true; _error = null; });
    try {
      final result = await AiService.getDocuments(
        widget.data['product']!,
        widget.data['country']!,
        widget.data['qty']!,
      );
      setState(() { _docs = result; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Documents', style: GoogleFonts.syne(fontWeight: FontWeight.w700)),
        backgroundColor: const Color(0xFF1a7a4a),
        foregroundColor: Colors.white,
      ),
      body: _loading
          ? const Center(child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(color: Color(0xFF1a7a4a)),
                SizedBox(height: 16),
                Text('AI is filling your documents...'),
              ]))
          : _error != null
              ? Center(child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, size: 48, color: Colors.red),
                      const SizedBox(height: 16),
                      const Text('Failed to load documents',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 8),
                      Text(_error!, textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                      const SizedBox(height: 24),
                      ElevatedButton.icon(
                        onPressed: _loadDocs,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Retry'),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1a7a4a),
                            foregroundColor: Colors.white),
                      ),
                    ],
                  )))
              : _buildDocs(),
    );
  }

  Widget _buildDocs() {
    final docs = [
      {'name': 'Commercial Invoice', 'key': 'invoice',
       'icon': Icons.receipt_long, 'color': Colors.blue,
       'where': 'Supplier signs — no stamp needed'},
      {'name': 'Packing List', 'key': 'packing_list',
       'icon': Icons.list_alt, 'color': Colors.orange,
       'where': 'Supplier signs — no stamp needed'},
      {'name': 'Goods Declaration (GD)', 'key': 'gd',
       'icon': Icons.account_balance, 'color': Colors.red,
       'where': 'Submit on WEBOC — FBR verifies'},
      {'name': 'Certificate of Origin', 'key': 'cert_origin',
       'icon': Icons.verified_outlined, 'color': Colors.amber[700]!,
       'where': 'Get stamp from TDAP or Chamber of Commerce'},
      {'name': 'Form-E (Export)', 'key': 'form_e',
       'icon': Icons.article_outlined, 'color': Colors.purple,
       'where': 'Take to your bank — they stamp it'},
    ];
    return ListView(padding: const EdgeInsets.all(20), children: [
      ...docs.map((doc) => _docCard(doc)),
    ]);
  }

  Widget _docCard(Map doc) {
    final content = _docs?[doc['key']] ?? 'Not available';
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.withOpacity(0.15))),
      child: ExpansionTile(
        leading: Icon(doc['icon'] as IconData, color: doc['color'] as Color),
        title: Text(doc['name'], style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        subtitle: Text(doc['where'], style: TextStyle(fontSize: 11, color: Colors.grey[600])),
        children: [
          Padding(padding: const EdgeInsets.all(16), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.withOpacity(0.2))),
                child: Text(content, style: const TextStyle(fontSize: 12, height: 1.6))),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Colors.green[50],
                  borderRadius: BorderRadius.circular(8)),
                child: Row(children: [
                  const Icon(Icons.info_outline, size: 16, color: Colors.green),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Next step: ${doc['where']}',
                    style: const TextStyle(fontSize: 12, color: Colors.green))),
                ]),
              ),
            ]))
        ],
      ),
    );
  }
}