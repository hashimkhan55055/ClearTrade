import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/ai_service.dart';

class OptionAScreen extends StatefulWidget {
  final Map<String, String> data;
  const OptionAScreen({super.key, required this.data});
  @override
  State<OptionAScreen> createState() => _OptionAScreenState();
}

class _OptionAScreenState extends State<OptionAScreen> {
  Map<String, dynamic>? _report;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadReport();
  }

  Future<void> _loadReport() async {
    try {
      final result = await AiService.getTradeReport(
        widget.data['product']!,
        widget.data['country']!,
        widget.data['qty']!,
      );
      setState(() { _report = result; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Trade Report', style: GoogleFonts.syne(fontWeight: FontWeight.w700)),
        backgroundColor: const Color(0xFF1a4a7a),
        foregroundColor: Colors.white,
      ),
      body: _loading
        ? const Center(child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('AI is analysing your trade...'),
            ]))
        : _error != null
          ? Center(child: Text('Error: $_error'))
          : _buildReport(),
    );
  }

  Widget _buildReport() {
    final r = _report!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _tile('HS Code', r['hs_code'] ?? '-', Icons.tag, Colors.blue),
        _tile('Customs Duty', r['customs_duty'] ?? '-', Icons.percent, Colors.red),
        _tile('Sales Tax (GST)', r['sales_tax'] ?? '-', Icons.receipt, Colors.orange),
        _tile('Additional Tax', r['additional_tax'] ?? '-', Icons.add_circle_outline, Colors.red),
        _tile('FTA Exemption', r['fta_exemption'] ?? '-', Icons.verified, Colors.green),
        _tile('Certificates Needed', r['cert_required'] ?? '-', Icons.badge_outlined, Colors.purple),
        _tile('Shipping Estimate', r['shipping_est'] ?? '-', Icons.local_shipping_outlined, Colors.blue),
        _tile('Total Landed Cost', r['landed_cost'] ?? '-', Icons.account_balance_wallet_outlined, Colors.green),
        _tile('Profit Margin', r['profit_margin'] ?? '-', Icons.trending_up, Colors.green),
        const SizedBox(height: 16),
        Text('Step-by-step process', style: GoogleFonts.syne(fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        ...List.generate((r['steps'] as List).length, (i) =>
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              CircleAvatar(radius: 13, backgroundColor: const Color(0xFF1a7a4a),
                child: Text('${i+1}', style: const TextStyle(color: Colors.white, fontSize: 11))),
              const SizedBox(width: 10),
              Expanded(child: Text(r['steps'][i], style: const TextStyle(fontSize: 13))),
            ]),
          )),
      ]),
    );
  }

  Widget _tile(String label, String value, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.withOpacity(0.15))),
      child: Row(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
          Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        ])),
      ]),
    );
  }
}