import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'option_a_screen.dart';
import 'option_b_screen.dart';
import '../widgets/ai_agent_section.dart'; // ← new import

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _productCtrl = TextEditingController();
  final _countryCtrl = TextEditingController();
  final _qtyCtrl    = TextEditingController();

  void _proceed(String option) {
    if (_productCtrl.text.isEmpty ||
        _countryCtrl.text.isEmpty ||
        _qtyCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }
    final data = {
      'product': _productCtrl.text,
      'country': _countryCtrl.text,
      'qty':     _qtyCtrl.text,
    };
    Navigator.push(context, MaterialPageRoute(builder: (_) =>
      option == 'A'
        ? OptionAScreen(data: data)
        : OptionBScreen(data: data),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9F6),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              // Logo area
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1a7a4a),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.swap_horiz, color: Colors.white, size: 28),
                ),
                const SizedBox(width: 12),
                Text('ClearTrade',
                  style: GoogleFonts.syne(fontSize: 26, fontWeight: FontWeight.w800,
                    color: const Color(0xFF1a7a4a))),
              ]),
              const SizedBox(height: 8),
              Text('AI Trade Copilot for Pakistan',
                style: TextStyle(fontSize: 14, color: Colors.grey[600])),
              const SizedBox(height: 32),
              // Input card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.withOpacity(0.15)),
                ),
                child: Column(children: [
                  _buildField(_productCtrl, 'Product', 'e.g. LED lights', Icons.inventory_2_outlined),
                  const SizedBox(height: 14),
                  _buildField(_countryCtrl, 'Country', 'e.g. China', Icons.flag_outlined),
                  const SizedBox(height: 14),
                  _buildField(_qtyCtrl, 'Quantity', 'e.g. 500 units', Icons.numbers_outlined),
                ]),
              ),
              const SizedBox(height: 24),
              Text('What do you need?',
                style: GoogleFonts.syne(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              // Option A
              _buildOptionCard(
                icon: Icons.analytics_outlined,
                color: const Color(0xFF1a4a7a),
                title: 'Guide me + show costs',
                subtitle: 'HS code, duties, taxes, profit estimate, step-by-step guidance',
                tag: 'Option A',
                onTap: () => _proceed('A'),
              ),
              const SizedBox(height: 12),
              // Option B
              _buildOptionCard(
                icon: Icons.description_outlined,
                color: const Color(0xFF1a7a4a),
                title: 'Generate my documents',
                subtitle: 'Auto-fill Invoice, Packing List, GD, Form-E, Certificate of Origin',
                tag: 'Option B',
                onTap: () => _proceed('B'),
              ),

              // ── AI Agent ────────────────────────────────────────
              const SizedBox(height: 24),
              Text('Ask AI Agent',
                style: GoogleFonts.syne(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              AiAgentSection(), // ← AI agent added here
              // ─────────────────────────────────────────────────────

              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(TextEditingController ctrl, String label,
      String hint, IconData icon) {
    return TextField(
      controller: ctrl,
      decoration: InputDecoration(
        labelText: label, hintText: hint,
        prefixIcon: Icon(icon, size: 20),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }

  Widget _buildOptionCard({required IconData icon, required Color color,
      required String title, required String subtitle,
      required String tag, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.3), width: 1.5),
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20)),
              child: Text(tag, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w600)),
            ),
            const SizedBox(height: 4),
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 3),
            Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
          ])),
          Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey[400]),
        ]),
      ),
    );
  }
}