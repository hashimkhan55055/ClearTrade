import 'dart:convert';
import 'package:http/http.dart' as http;

class AiService {
  static const String _apiKey = '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';
  static const String _url = 'https://api.anthropic.com/v1/messages';

  static Future<Map<String, dynamic>> getTradeReport(
      String product, String country, String qty) async {
    final prompt = """
You are ClearTrade, an AI trade consultant for Pakistan.
User wants to import $qty of "$product" from $country.
Reply ONLY with valid JSON, no markdown, no explanation:
{
  "hs_code": "8-digit HS code",
  "customs_duty": "percentage e.g. 20%",
  "sales_tax": "percentage e.g. 17%",
  "additional_tax": "percentage or None",
  "fta_exemption": "yes/partial/no + brief note",
  "cert_required": "certificate name or None",
  "shipping_est": "PKR range e.g. PKR 40,000-60,000",
  "landed_cost": "total estimated PKR",
  "profit_margin": "estimated % range",
  "recommendation": "one sentence go/no-go",
  "steps": ["step 1", "step 2", "step 3", "step 4", "step 5"]
}""";
    return await _call(prompt);
  }

  static Future<Map<String, dynamic>> getDocuments(
      String product, String country, String qty) async {
    final prompt = """
You are ClearTrade. Generate trade documents for Pakistan.
Product: $product, Country: $country, Quantity: $qty
Reply ONLY with valid JSON:
{
  "invoice": "Full commercial invoice text with all fields filled",
  "packing_list": "Full packing list with boxes, weights, contents",
  "gd": "Goods Declaration draft with HS code, values, NTN fields",
  "cert_origin": "Certificate of Origin draft with all fields",
  "form_e": "Form-E draft with all export fields filled"
}""";
    return await _call(prompt);
  }

  static Future<Map<String, dynamic>> _call(String prompt) async {
    final response = await http.post(
      Uri.parse(_url),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': _apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode({
        'model': 'claude-haiku-4-5-20251001',
        'max_tokens': 1500,
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
      }),
    );

    final body = jsonDecode(response.body);

    if (response.statusCode != 200) {
      final errorMsg = body['error']?['message'] ?? 'Unknown API error';
      throw Exception('API Error ${response.statusCode}: $errorMsg');
    }

    final content = body['content'];
    if (content == null || content.isEmpty) {
      throw Exception('Empty response from API: ${response.body}');
    }

    final text = content[0]['text'] as String;
    final clean = text.replaceAll('```json', '').replaceAll('```', '').trim();

    try {
      return jsonDecode(clean);
    } catch (e) {
      throw Exception('Failed to parse AI response as JSON: $clean');
    }
  }
}