import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const _kGreen = Color(0xFF1A6B4A);
const _kBorder = Color(0xFFD0E8DB);
const _kBg = Color(0xFFF0F7F3);
const _kMuted = Color(0xFF6B8F7A);
const _kText = Color(0xFF1A2E23);

const _kApiKey = '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';

class AiAgentSection extends StatefulWidget {
  const AiAgentSection({super.key});

  @override
  State<AiAgentSection> createState() => _AiAgentSectionState();
}

class _AiAgentSectionState extends State<AiAgentSection> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<_ChatMessage> _messages = [
    _ChatMessage(
      text: "Assalam-o-Alaikum! I'm your AI trade agent. Ask me anything about HS codes, import duties, or documentation for Pakistan trade. 🇵🇰",
      isUser: false,
    ),
  ];

  bool _chipsVisible = true;
  bool _isLoading = false;

  final List<String> _chips = [
    'HS code for LED lights',
    'Duties from China',
    'Required documents',
    'Form-E explained',
  ];

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty || _isLoading) return;

    setState(() {
      _messages.add(_ChatMessage(text: text, isUser: true));
      _chipsVisible = false;
      _isLoading = true;
    });
    _scrollToBottom();

    try {
      final response = await http.post(
        Uri.parse('https://api.anthropic.com/v1/messages'),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': _kApiKey,
          'anthropic-version': '2023-06-01',
        },
        body: jsonEncode({
          'model': 'claude-sonnet-4-20250514',
          'max_tokens': 1000,
          'system': '''You are ClearTrade AI Agent — an expert AI Trade Copilot for Pakistan importers and exporters. You help users with:
- HS codes and product classification
- Import duties, taxes, and tariffs for Pakistan
- Required trade documents (GD, Form-E, Invoice, Packing List, Certificate of Origin)
- Step-by-step import/export guidance
- Trade compliance for products coming from countries like China, UAE, UK etc.

Keep answers concise, practical, and Pakistan-specific. Use friendly Urdu words occasionally (like "bilkul", "zaroor") to feel local. Format with short bullets when listing items. Always be helpful and encouraging.''',
          'messages': [
            {'role': 'user', 'content': text}
          ],
        }),
      );

      print('STATUS: ${response.statusCode}');
      print('BODY: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final reply = (data['content'] as List)
            .where((b) => b['type'] == 'text')
            .map((b) => b['text'] as String)
            .join('');
        setState(() {
          _messages.add(_ChatMessage(text: reply, isUser: false));
        });
      } else {
        final errorData = jsonDecode(response.body);
        final errorMsg = errorData['error']?['message'] ?? 'Unknown error';
        setState(() {
          _messages.add(_ChatMessage(
            text: 'Error ${response.statusCode}: $errorMsg',
            isUser: false,
          ));
        });
      }
    } catch (e) {
      print('EXCEPTION: $e');
      setState(() {
        _messages.add(_ChatMessage(
          text: 'Network error: $e',
          isUser: false,
        ));
      });
    } finally {
      setState(() => _isLoading = false);
      _scrollToBottom();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBorder, width: 0.5),
      ),
      clipBehavior: Clip.hardEdge,
      child: Column(
        children: [
          _buildHeader(),
          _buildChatArea(),
          if (_chipsVisible) _buildChips(),
          _buildInputRow(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      color: _kGreen,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.18),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.smart_toy_outlined, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ClearTrade AI Agent',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
                Text('Your trade compliance copilot',
                    style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: const Color(0xFF5EE89C),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF5EE89C).withOpacity(0.4),
                  blurRadius: 4,
                  spreadRadius: 2,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatArea() {
    return Container(
      color: _kBg,
      constraints: const BoxConstraints(minHeight: 180, maxHeight: 280),
      child: ListView.separated(
        controller: _scrollController,
        padding: const EdgeInsets.all(14),
        itemCount: _messages.length + (_isLoading ? 1 : 0),
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          if (i == _messages.length) return _buildTypingIndicator();
          return _buildBubble(_messages[i]);
        },
      ),
    );
  }

  Widget _buildBubble(_ChatMessage msg) {
    return Row(
      mainAxisAlignment: msg.isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!msg.isUser) ...[
          Container(
            width: 28,
            height: 28,
            decoration: const BoxDecoration(color: _kGreen, shape: BoxShape.circle),
            child: const Icon(Icons.smart_toy_outlined, color: Colors.white, size: 14),
          ),
          const SizedBox(width: 8),
        ],
        Flexible(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: msg.isUser ? _kGreen : Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(msg.isUser ? 14 : 4),
                topRight: Radius.circular(msg.isUser ? 4 : 14),
                bottomLeft: const Radius.circular(14),
                bottomRight: const Radius.circular(14),
              ),
              border: msg.isUser ? null : Border.all(color: _kBorder, width: 0.5),
            ),
            child: Text(
              msg.text,
              style: TextStyle(
                color: msg.isUser ? Colors.white : _kText,
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTypingIndicator() {
    return Row(
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: const BoxDecoration(color: _kGreen, shape: BoxShape.circle),
          child: const Icon(Icons.smart_toy_outlined, color: Colors.white, size: 14),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _kBorder, width: 0.5),
          ),
          child: Row(
            children: List.generate(
              3,
              (i) => _TypingDot(delay: Duration(milliseconds: i * 200)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildChips() {
    return Container(
      color: _kBg,
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: Wrap(
        spacing: 6,
        runSpacing: 6,
        children: _chips.map((chip) {
          return GestureDetector(
            onTap: () => _sendMessage(chip),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _kBorder, width: 0.5),
              ),
              child: Text(chip, style: const TextStyle(color: _kGreen, fontSize: 12)),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildInputRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: _kBorder, width: 0.5)),
      ),
      child: Row(
        children: [
          const Icon(Icons.chat_bubble_outline, size: 18, color: _kMuted),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _controller,
              style: const TextStyle(fontSize: 13, color: _kText),
              decoration: const InputDecoration(
                hintText: 'Ask about duties, HS codes, documents…',
                hintStyle: TextStyle(fontSize: 13, color: _kMuted),
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero,
              ),
              onSubmitted: (val) {
                _sendMessage(val);
                _controller.clear();
              },
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () {
              _sendMessage(_controller.text);
              _controller.clear();
            },
            child: Container(
              width: 32,
              height: 32,
              decoration: const BoxDecoration(color: _kGreen, shape: BoxShape.circle),
              child: const Icon(Icons.arrow_upward, color: Colors.white, size: 14),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatMessage {
  final String text;
  final bool isUser;
  _ChatMessage({required this.text, required this.isUser});
}

class _TypingDot extends StatefulWidget {
  final Duration delay;
  const _TypingDot({required this.delay});

  @override
  State<_TypingDot> createState() => _TypingDotState();
}

class _TypingDotState extends State<_TypingDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat();
    _anim = Tween(begin: 0.2, end: 1.0).animate(CurvedAnimation(
      parent: _ctrl,
      curve: Interval(widget.delay.inMilliseconds / 1200, 1.0, curve: Curves.easeInOut),
    ));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _anim,
      child: Container(
        width: 6,
        height: 6,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: const BoxDecoration(color: _kMuted, shape: BoxShape.circle),
      ),
    );
  }
}