package com.example.cleartrade

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
